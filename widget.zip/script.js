var list_custom_fields=$('.card-holder__container.custom-scroll');
	//console.dir($(list_custom_fields).find('input'));
	var mas=$(list_custom_fields.find('div[class="linked-form__field__label"]'));
	$(mas).each(
		function(i,elem)
		{		
				try
				{
					console.log($($(elem).children('span')).html());
                
				if($(elem).children('span').html().length >= 35)
                {
					console.log('456');
					
					$(elem).css({ "width": "400px",
							"white-space": "normal"});
					
						$(elem).css("overflow-x", "inherit");
					
					$(elem).children('span').css({"width": "400px", 
							"word-wrap": "break-word"});

					
				}
			}
			catch(e)
			{
				console.dir(e);
			}
		}
	
	);


define(['jquery'], function($){
    var CustomWidget = function () {
    	var self = this;
		this.callbacks = {
			render: function(){
				console.log('render');
				return true;
			},
			init: function(){
				console.log('init');
				return true;
			},
			bind_actions: function(){
				console.log('bind_');
				get_last_lead();
				return true;
			},
			settings: function(){
				return true;
			},
			onSave: function(){
				alert('click');
				return true;
			},
			destroy: function(){
				
			},
			contacts: {
					//select contacts in list and clicked on widget name
					selected: function(){
						console.log('contacts');
					}
				},
			leads: {
					//select leads in list and clicked on widget name
					selected: function(){
						console.log('leads');
					}
				},
			tasks: {
					//select taks in list and clicked on widget name
					selected: function(){
						console.log('tasks');
					}
				}
		};
		return this;
    };

return CustomWidget;
});