function get_last_lead()
{	
	console.log("куку10");
	var list_custom_fields=$('.card-holder__container.custom-scroll');
	//console.dir($(list_custom_fields).find('input'));
	var mas=$(list_custom_fields.find('input[type="text"]'));
	
	$(mas).each(
		function(i,elem)
		{
				if($(elem).val().length >= 31)
				{
					var value=$(elem).val();
					var class_=$(elem).attr('class');
					
					$(elem).css('display','none');
					var name=$(elem).attr('name');
					console.log('456');
					console.log(class_,name,value);
					var str="<textarea class="+class_+" name="+name+">"+value+"</textarea>";
					
					$($(elem).parent()).append(str);
				}
		}
	
	);
};


define(['jquery'], function($){
    var CustomWidget = function () {
    	var self = this;
		this.callbacks = {
			render: function(){
				console.log('render');
				return true;
			},
			init: function(){
				console.log('init');
				return true;
			},
			bind_actions: function(){
				console.log('bind_');
				get_last_lead();
				return true;
			},
			settings: function(){
				return true;
			},
			onSave: function(){
				alert('click');
				return true;
			},
			destroy: function(){
				
			},
			contacts: {
					//select contacts in list and clicked on widget name
					selected: function(){
						console.log('contacts');
					}
				},
			leads: {
					//select leads in list and clicked on widget name
					selected: function(){
						console.log('leads');
					}
				},
			tasks: {
					//select taks in list and clicked on widget name
					selected: function(){
						console.log('tasks');
					}
				}
		};
		return this;
    };

return CustomWidget;
});